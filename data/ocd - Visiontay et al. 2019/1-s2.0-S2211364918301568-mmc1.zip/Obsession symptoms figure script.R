library('qgraph')
library('ggplot2')
library('data.table')
library('reshape2')
library('psych')
library('ade4')
library('viridis')


##### OBSESSIONS FIGURE
set.seed(223)
obs_figure_data <- read.csv(file.choose(), header=T)
obs_figure_data<-as.data.table(obs_figure_data) #to coerce into a data table
obs_figure_data[, S := factor(paste0("S",1:nrow(obs_figure_data)))] #Create symptom variable
obs_figure_data = melt(obs_figure_data, id.vars="S", variable.name="Scales", value.name="Type") #Transform to long format
obs_figure_data = obs_figure_data[Type>=1] #Keep the scales in which the symptoms are 1 (present) or 2 (included)
obs_figure_data[, Type := factor(Type, labels=c("Scale contains compound symptom", "Scale contains specific symptom"))]
obs_figure_data[, count := .N, by=S]

# Symptom order
sympt.order = obs_figure_data[, .N, by=S][order(N)][, S] #Replace by order
obs_figure_data[, S := factor(S, levels = sympt.order)]

# Scale order by frequency
scale.order = obs_figure_data[, .N, by=Scales][order(N)][, Scales]
obs_figure_data[, Scales := factor(Scales, levels = scale.order)]
obs_figure_data[, Scales2 := as.numeric(Scales)]


# making colour palette for plot
pal1 <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# making plot
obsessions_plot<- ggplot(obs_figure_data, aes(x=S, y=Scales2, group=S, color=as.factor(Scales), shape=Type, rev=F)) +
  geom_line() + #keep this here, otherwise there is an error 
  xlab("") +
  ylab("") +
  # Generate the grid lines
  #1:7 for number of scales, 1:32 for number of symptoms RV
  geom_hline(yintercept = 1:7, colour = "grey80", size = .2) +
  geom_vline(xintercept = 1:32, colour = "grey80", size = .2) +
  # Points and lines
  geom_line(colour="grey60") +
  geom_point(size=3, fill="white") +
  # Fill the middle space with a white blank rectangle
  geom_rect(xmin=-Inf,xmax=Inf,ymin=-Inf,ymax=.6,fill="white", color=NA) +
  # Polar coordinates (THIS IS THE PART THAT MAKES IT INTO A CIRCLE-SHAPE)
  #scale shape manual changes shapes of the plot points
  coord_polar() +
  scale_shape_manual(values=c(21,19)) +
  theme (
    panel.border = element_blank(),
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    panel.grid = element_blank(),
    panel.background = element_blank(),
    legend.position="right", #changed position so would fit on screen
    legend.text = element_text(size = 10), 
    legend.title = element_blank(), #to remove legend titles
    plot.margin = unit(rep(.5,4), "lines")) +
  labs(fill="") + # remove legend title
  scale_y_continuous(limits=c(-4,7), expand=c(0,0), breaks=1:7, labels= NULL) +  
  scale_color_manual(values=pal1) 
 

ggsave(plot=obsessions_plot,filename="overlap_plot_obsessions.pdf", width=7, height=7, useDingbats=FALSE)

